from django.db import models
from cpf_field.models import CPFField
from uuid import uuid4
from validate_email import validate_email

# Create your models here.


class Cadastro(models.Model): 
    id_cliente = models.UUIDField(primary_key=True, default=uuid4, editable=False)
    cpf_cliente = CPFField('cpf')
    email_cliente = models.CharField(max_length=255)
    
